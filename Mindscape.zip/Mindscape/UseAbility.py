import time

#appears in this order
import Battles
import Display
import CheckStatus
import ChooseAbility
import ChooseTarget
import DamageCalculations
import HealingCalculations
import ApplyNonstatusEffect
import InsertStatusEffect

#this is where turns take place
def useAbility(user, enemies, teammates, combatants):
    timeWait = 0.33
    user.turnGauge = 0 #this must be placed early to have added turn gauge points work properly
    
    #check for if the character is defeated
    if user.FOR <= 0:
        print(f"\n{user.name} is asleep.")
        
        time.sleep(timeWait)
    else: #if they are awake
        #for displaying the turn gauges and fortitude's of everyone
        
        print(" ")
        for chara in combatants:
            Display.displayGeneralFortitude(chara)
            Display.displayTurnGauge(chara)
    
        print(f"\nIt is now {user.name}'s turn\n")
        confirmContinue = input("PRESS ENTER TO CONTINUE")
        
        user.alterAllFocus(1)
        
        #----------------------------- unique activation for provocation and pacification
        #checks if the user is both pacified AND provoked
        if "PAC" in user.statusList and "PRV" in user.statusList:
            print(f"{user.name} is both provoked AND pacified, how useless!")
            time.sleep(timeWait)
    
        #checks if the user has any non-damaging ability if they are pacified
        elif "PAC" in user.statusList and user.ability1.power > 0 and user.ability2.power > 0 and user.ability3.power > 0 and user.ability4.power > 0:
            print(f"{user.name} is pacified with only damaging abilities! Useless, useless, useless!")
            time.sleep(timeWait)
        
        #checks if the user has any damaging abilities if they are provoked
        elif "PRV" in user.statusList and user.ability1.power < 0 and user.ability2.power < 0 and user.ability3.power < 0 and user.ability4.power < 0:
            print(f"{user.name} is provoked with only non-damaging abilities! Useless, useless, useless!")
            time.sleep(timeWait)
        #------------------------------ if the turn can proceed normally
        else:
            abilityX = ChooseAbility.chooseAbility(user)
            time.sleep(timeWait)
            
            target = ChooseTarget.chooseTarget(abilityX, user, enemies, teammates, combatants)
            time.sleep(timeWait)
            
            if abilityX == user.ability1:
                relevantFocus = user.ability1Focus
            elif abilityX == user.ability2:
                relevantFocus = user.ability2Focus
            elif abilityX == user.ability3:
                relevantFocus = user.ability3Focus
            elif abilityX == user.ability4:
                relevantFocus = user.ability4Focus
            
            #if you have enough focus for that ability, it executes
            if relevantFocus >= 3:
            
                #calculates damage, healing and effects for each target
                for chara in target: #iterates through each character established as a target from chooseTarget
                    damage = 0
                    healing = 0
                    
                    if abilityX.power > 0:
                        damage = DamageCalculations.calculateDamage(user, chara, enemies, abilityX)
                    else:
                        healing = HealingCalculations.calculateHealing(user, chara, teammates, abilityX)
                    
                    time.sleep(timeWait)
                    
                    #adds a status to a statusList or activates some other effect
                    ApplyNonstatusEffect.applyImmediateEffect(user, chara, damage, abilityX)
                    InsertStatusEffect.applyStatus(user, chara, abilityX)
                    
                    #notifies the user if their ability eliminated an opponent
                    if chara.FOR <= 0:
                        print(f"{chara.name} has fallen asleep!")
                
                user.depleteFocus(abilityX, 3)
                
                #confirmContinue = input("PRESS ENTER TO CONTINUE\n")
                
                return abilityX
            else: #if you do not have enough focus to execute your ability, the user is punished
                print(f"{abilityX.name} fails from a lack of focus\n")