import time

#checks for if a status should be removed or persist
#activates DOT and HOT, due to their unique mechanics
#checkStatus is iterated over in the Battles module

#makes it easier to tell the user about statuses
def showStatus(status):
    if status == "VE":
        print("veiled.")
    elif status == "BG":
        print("body guarding.")
    elif status == "END":
        print("enduring.")
    elif status == "PRV":
        print("provoked.")
    elif status == "PAC":
        print("pacified.")
    elif status == "DOT":
        print("to be receiving damage over time.")
    elif status == "HOT":
        print("to be receiving healing over time.")
    elif status == "DEF":
        print("defending.")
    elif status == "VUL":
        print("vulnerable.")
    elif status == "LIB":
        print("liberated.")
    elif status == "OPP":
        print("oppressed.")

def checkStatus(chara):
    timeWait = 0.5
    #print("CheckStatus entered!")
    
    shortStatuses = ["PRV", "PAC"]
    mediumStatuses = ["VUL","DEF","OPP","LIB","SOR","RAG","DIS","VIB"]
    longStatuses = ["VE", "END", "DOT", "HOT", "BG"]
    
    for status in chara.statusList:
        #print("Status list iteration entered")
        if status in shortStatuses:
            statusINI = 125
        if status in mediumStatuses:
            statusINI = 100
        if status in longStatuses:
            statusINI = 80
        
        n = chara.statusList.index(status)
        
        #if that status ends
        if chara.statusCounterList[n] >= 5000:
            #print("If status ends entered")
            
            #"resetting" stats that were temporary changed
            if status == "VUL":
                chara.PER += chara.tempPERdown
            elif status == "DEF":
                chara.PER -= chara.tempPERup  
            elif status == "OPP":
                chara.INI += chara.tempINIdown
            elif status == "LIB":
                chara.INI -= chara.tempINIup
            elif status == "SOR":
                chara.PAS += chara.tempPASdown
            elif status == "RAG":
                chara.PAS -= chara.tempPASup
            elif status == "DIS":
                chara.COM += chara.tempCOMdown
            elif status == "VIB":
                chara.COM -= chara.tempCOMup
                
            chara.statusList.remove(status)
            chara.statusCounterList.remove(5000)
            print(f"{chara.name} is no longer ", end="")
            showStatus(status)
            time.sleep(timeWait)
        else: #if the status persists
            #print("Increasing statusCounterList")
            chara.statusCounterList[n] += statusINI
            
            #activating DOT and HOT every 10 ticks
            if chara.statusCounterList[n] % 500 == 0:
                if status == "DOT":
                    chara.FOR -= int(chara.defaultFOR/8)
                    print(f"{chara.name} is hurt by continuous damage for {chara.defaultFOR/8} fortitude.\n")
                    
                    #enduring can activate here too
                    if 'END' in chara.statusList and chara.FOR <= 0:
                        chara.FOR = 1
                        print(f"{chara.name} has endured damage over time!")
                if status == "HOT":
                    chara.FOR += int(chara.defaultFOR/8)
                    print(f"{chara.name} is assisted by continuous healing for {chara.defaultFOR/8} fortitude.\n")
            
            #reminds the user that a chara is afflicted with a given status
            if chara.statusCounterList[n] == statusINI * 28 or chara.statusCounterList[n] == statusINI * 56:
                #print(f"Counter list at index n: {chara.statusCounterList[n]}")
                print(f"{chara.name} remains ", end="")
                showStatus(status)
                time.sleep(timeWait)   