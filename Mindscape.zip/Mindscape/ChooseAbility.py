#used in the character attack method to give options
import Battles
#from Ability import Ability
import random

def chooseAbility(chara):
    isValidChoice = False
    while isValidChoice == False:
        print(" ")
        #abilityX = Ability("Ability X", 0, 0, 3, "self") #temp initialization
        
        if Battles.isAI == True:
            abilityNum = random.randint(1,4)
        else:
            print("Select an ability... (select a number from 1 to 4, then select enter)")
            print(f" 1. {chara.ability1.name}    (focus: {chara.ability1Focus}/{chara.ability1.maxFocus})")
            print(f" 2. {chara.ability2.name}    (focus: {chara.ability2Focus}/{chara.ability2.maxFocus})")
            print(f" 3. {chara.ability3.name}    (focus: {chara.ability3Focus}/{chara.ability3.maxFocus})")
            print(f" 4. {chara.ability4.name}    (focus: {chara.ability4Focus}/{chara.ability4.maxFocus})")
            
            try:
                abilityNum = int(input())
            except ValueError:
                print("Invalid input, try again")
                continue

        if abilityNum == 1:
            abilityX = chara.ability1
        elif abilityNum == 2:
            abilityX = chara.ability2
        elif abilityNum == 3:
            abilityX = chara.ability3
        elif abilityNum == 4:
            abilityX = chara.ability4
        isValidChoice = True
        
        if "PAC" in chara.statusList and abilityX.power > 0:
            print("You are pacified, you cannot choose a damaging ability...")
            isValidChoice = False
            
        if "PRV" in chara.statusList and abilityX.power < 0:
            print("You are provoked, you cannot choose a non-damaging ability...")
            isValidChoice = False
    return abilityX