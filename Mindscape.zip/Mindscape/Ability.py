class Ability:
    def __init__(self, name, power, maxFocus, targetSetting):
        self.name = name
        self.power = power
        self.maxFocus = maxFocus
        self.addiEffect = [] #The set of additional effects a move can have
        #determines whether it affects your team or the enemy team
        self.targetSetting = targetSetting
    def getAllAddiEffects(self):
        return self.addiEffect
    def giveEffect(self, effect): #gives an effect to the list of additional effects for a move
        self.addiEffect.append(effect)