#also calculates zero power abilitys
def calculateHealing(user, target, teammates, abilityX):
    healing = 0
    #revival abilitys only heal defeated targets
    if "REV" in abilityX.getAllAddiEffects() and target.FOR > 0:
        print("Revival failed!")
    else:
        
        userCOMproxy = user.COM
        
        if userCOMproxy < 0:
            userCOMproxy = 0
        
        #divided by -1 to make healing positive (easier to read)
        healing = int(user.COM * abilityX.power/-2) #healing changed to be pos
        #-------------------- if the healing is over the max, remove the amount that went over
        if (target.FOR + healing) > target.maxFOR:
            excessHealing = target.FOR - (target.maxFOR) #identify the amount that is over the max
            target.FOR = target.maxFOR #cap the FOR back to the max
            healing -= excessHealing #healing is changed b/c of prints
        #--------------------- end of excess healing calculation
        target.FOR += healing
        
        #different text for targeting oneself
        if abilityX.power == 0:
            if target == user:
                print(f"{user.name} uses {abilityX.name} on themself")
            else:
                print(f"{user.name} uses {abilityX.name} on {target.name}")
        
        if abilityX.power < 0:
            if target == user:
                print(f"{user.name} uses {abilityX.name} on themself for {healing} healing!")
            else:
                print(f"{user.name} uses {abilityX.name} on {target.name} for {healing} healing!")
    return healing