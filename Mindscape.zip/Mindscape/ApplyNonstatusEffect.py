import time
import Display
timeWait = 0.25

#these ability effects are not added to the statusList of characters (but they may involve it)
#often activates the status effects of the target
def applyImmediateEffect(user, target, damage, abilityX):
    #----------------------- activating non-statistic nonstatus effects
    #activating character read
    if "CR" in abilityX.getAllAddiEffects():
        if "VE" in target.statusList:
            print(f"{target.name} has blocked information with their veil")
        else:
            time.sleep(timeWait)
            Display.displayInfo(target)
            time.sleep(timeWait)
            
    #endurance activation
    if target.FOR <= 0 and "END" in target.statusList:
        target.FOR = 1
        print(f"{target.name} endured the hit!")
        
    #life stealing
    if "LS" in abilityX.getAllAddiEffects():
        stolenFOR = damage/2
        user.FOR += stolenFOR
        if (user.FOR + stolenFOR) > (user.maxFOR):
            excessHealing = user.FOR - (user.maxFOR)
            target.FOR = target.maxFOR #cap the FOR back to the max
            round(stolenFOR, 2)
            stolenFOR -= excessHealing
        print(f"{user.name} recovered {stolenFOR} fortitude!")
        time.sleep(timeWait)
        
    #turn gauge increase
    if "TGu" in abilityX.getAllAddiEffects():
        n = abilityX.getAllAddiEffects().index("TGu")
        if abilityX.addiEffect[n+1] == "self":
            user.turnGauge += 2000
            print(f"{user.name} is ready for another move")
        else:
            target.turnGauge += 2000
            print(f"{target.name} is ready for another move")
    
    #turn gauge decrease
    if "TGd" in abilityX.getAllAddiEffects():
        n = abilityX.getAllAddiEffects().index("TGd")
        if abilityX.addiEffect[n+1] == "self":
            user.turnGauge -= 2000
            print(f"{user.name} is knocked back")
        else:
            target.turnGauge -= 2000
            print(f"{target.name} is knocked back")
    
    #cleansing
    if "CLE" in abilityX.getAllAddiEffects():
        n = abilityX.getAllAddiEffects().index("CLE")
        if abilityX.addiEffect[n+1] == "self":
            user.statusList.clear()
            user.statusCounterList.clear()
            print(f"{user.name} has been cleansed")
        else:
            target.statusList.clear()
            target.statusCounterList.clear()
            print(f"{target.name} has been cleansed")
    
    #sacrifice
    if "SAC" in abilityX.getAllAddiEffects():
        sacDMG = int(user.defaultFOR/4)
        user.FOR -= sacDMG
        print(f"{user.name} sacrificed {sacDMG} damage")
    
    #recoil
    if "RC" in abilityX.getAllAddiEffects():
        rcDMG = int(damage/4)
        print(f"{user.name} received {rcDMG} recoil damage")
        user.FOR -= rcDMG
    
    #focus up
    if "Fu" in abilityX.getAllAddiEffects():
        n = abilityX.getAllAddiEffects().index("Fu")
        if abilityX.addiEffect[n+1] == "self":
            user.alterAllFocus(0.5)
            print(f"{user.name} is feeling more focused")
        else:
            target.alterAllFocus(0.5)
            print(f"{target.name} is feeling more focused")
    
    #focus down
    if "Fd" in abilityX.getAllAddiEffects():
        n = abilityX.getAllAddiEffects().index("Fd")
        if abilityX.addiEffect[n+1] == "self":
            user.alterAllFocus(-0.5)
            print(f"{user.name} is feeling less focused")
        else:
            target.alterAllFocus(-0.5)
            print(f"{target.name} is feeling less focused")
    
    #----------------------- activating statistic nonstatus effects
    includedStatChanges = ["PASu", "PASd", "INIu", "INId", "COMu", "COMd", "PERu", "PERd"]
    
    for statChange in abilityX.getAllAddiEffects():
        if statChange not in includedStatChanges:
            continue
        else: #if the effect exists in the includedStatChanges
            n = abilityX.getAllAddiEffects().index(statChange)
            if abilityX.addiEffect[n+1] == "self":
                realTarget = user
            else: #if the move does not target oneself
                realTarget = target
            
            #after deciding who the real target is
            print(f"{realTarget.name}", end="")
            
            if statChange == "PASu":
                realTarget.PAS += user.COM/4
                print(" is feeling impassioned")
            elif statChange == "PASd":
                realTarget.PAS -= user.defaultStatTotal/16
                print(" is feeling dispassioned")
            elif statChange == "INIu":
                realTarget.INI += user.COM/4
                print(" is feeling swifter")
            elif statChange == "INId":
                realTarget.INI -= user.defaultStatTotal/16
                print(" is feeling more sluggish")
            elif statChange == "COMu":
                realTarget.COM += user.COM/4
                print(" is feeling more compassionate")
            elif statChange == "COMd":
                realTarget.COM -= user.defaultStatTotal/16
                print(" is feeling less compassionate")
            elif statChange == 'PERu':
                realTarget.COM += user.COM/4
                print(" is feeling more persistent")
            elif statChange == 'PERd':
                realTarget.PER -= user.defaultStatTotal/16
                print(" is feeling less persistent")
            
            time.sleep(timeWait)