import time

def calculateDamage(user, target, enemies, abilityX):
    timeWait = 0.5
    
    #default damage to avoid errors
    damage = 0
    
    #for handling how invincibility occurs
    if "IGN" in abilityX.getAllAddiEffects():
        if "END" or "BG" or "DEF" in target.statusList:
            print(f"{user.name}'s attack ignored {target.name}'s defenses!")
        
    #increasing damage based on the number of statuses on the target
    statusDMGMult = 1
    if "statusDMG" in abilityX.getAllAddiEffects():
        for status in target.statusList:
            statusDMGMult += 0.1
            
        if statusDMGMult > 1:
            print("Exceptional damage has been added because of the target's statuses")
    
    #to avoid negative damage (healing) from an otherwise damaging move
    userPASproxy = user.PAS
    if userPASproxy < 0:
        userPASproxy = 0
    
    targetPERproxy = target.PER
    if targetPERproxy < 1:
        targetPERproxy = 1
    
    #"ignores" the target's raised defenses by using their default
    if "IGN" in abilityX.getAllAddiEffects():
        targetPERproxy = target.defaultPER
    
    #core damage calculation (applies damage to target after body guarding check)
    damage = int(userPASproxy/(targetPERproxy) * (abilityX.power/2) * statusDMGMult)
    
    #body guarding activation (anyone with body guarding takes some of the damage)
    for chara in enemies:
        checkNum = 0
        if "BG" in chara.statusList and checkNum == 0 and target != chara and "IGN" not in abilityX.getAllAddiEffects():
            checkNum = 1
            damage = damage/3
            chara.FOR -= damage
            print(f"{chara.name} partially protected {target.name} from damage")
            
    if 'END' in target.statusList and target.FOR <= 0:
        target.FOR = 1
        print(f"{target.name} has endured the hit!")
        if 'IGN' in abilityX.getAllAddiEffects():
            target.FOR = 0
            print(f"...BUT IT WAS IGNORED")
    
    target.FOR -= damage
    
    print(f"{user.name} uses {abilityX.name} on {target.name} for {damage} damage")    

    time.sleep(timeWait)
    return damage