import time
timeWait = 0.25
#this module is for appending statuses to status lists and activating them, if applicable

#exclusively for adding statuses to statusLists. Used in applyStatus
def applyToRealTarget(realTarget, status, user, target):
    realTarget.addStatus(status)
    realTarget.statusCounterList.append(0)
    print(f"{realTarget.name}", end="")
    if status == "PAC":
        print(" is pacified!")
    elif status == "PRV":
        print(" is provoked!")
    elif status == "DOT":
        print(" is inflicted with damage over time!")
    elif status == "HOT":
        print(" is bestowed with healing over time!")
    elif status == "END":
        print(" will endure hits!")
    elif status == "BG":
        print(" is guarding their allies")
    elif status == "VE":
        print(" has been veiled")
    elif status == 'BG':
        print(" is body guarding their team")
    
    #persistence raising and reduction
    elif status == "DEF":
        #targets PER is increased based from the user's COM
        realTarget.tempPERup = user.COM/2
        realTarget.PER =+ realTarget.tempPERup
        print(" is defending: their persistence is massively raised")
        
    elif status == "VUL":
        realTarget.tempPERdown = user.defaultStatTotal/8
        realTarget.PER =- realTarget.tempPERdown
        print(" is vulnerable: their persistence is massively reduced")
    
    #initiative raising and reduction
    elif status == "LIB":
        realTarget.tempINIup = user.COM/2
        realTarget.INI =+ realTarget.tempINIup
        print(" has been liberated: their initiative is massively raised")
    
    elif status == "OPP":
        realTarget.tempINIdown = user.defaultStatTotal/8
        realTarget.INI =- realTarget.tempINIdown
        print(" has been bound: their initiative is massively reduced")
    
    #passion raising and reduction
    elif status == "RAG":
        realTarget.tempPASup = user.COM/2
        realTarget.PAS =+ realTarget.tempPASup
        print(" has been enraged: their passion is massively increased")
        
    elif status == "SOR":
        realTarget.tempPASdown = user.defaultStatTotal/8
        realTarget.PAS =- realTarget.tempPASdown
        print(" has been sorrowed: their passion is massively reduced")
    
    #compassion raising and reduction
    elif status == "VIB":
        realTarget.tempCOMup = user.COM/2
        realTarget.COM =+ realTarget.tempCOMup
        print(" has become vibrant: their compassion is massively increased")
        
    elif status == "DIS":
        realTarget.tempCOMdown = user.defaultStatTotal/8
        realTarget.COM =- realTarget.tempCOMdown
        print(" has been disgusted: their compassion is massively reduced")

    time.sleep(timeWait)
#adding statuses to statusLists
def applyStatus(user, target, abilityX):
    #this list is to avoid adding a non-status effect to a chara's status list
    includedStatuses = ["PAC", "DEF", "END", "BG", "VE", "DOT", "VUL", "HOT", "PRV", "LIB", "OPP"]
    
    for status in abilityX.getAllAddiEffects():
        #if the given effect is not a status effect, move to the next effect
        if status not in includedStatuses:
            continue
        else:
            n = abilityX.getAllAddiEffects().index(status)
            
            #realTarget is for creating uniformity between the user and the target, because the target could be the user
            if status not in target.statusList and abilityX.addiEffect[n+1] != "self":
                realTarget = target
                applyToRealTarget(realTarget, status, user, target)
            elif status not in user.statusList and abilityX.addiEffect[n+1] == "self":
                realTarget = user
                applyToRealTarget(realTarget, status)