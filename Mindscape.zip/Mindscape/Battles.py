import Display
import UseAbility
import CheckStatus

timeWait = 1
isTutorial = False
isAI = False

def battle(team1, team2):
    print("A battle commences between...!")
    print(f"Team 1: {team1[0].name}, {team1[1].name}, {team1[2].name}, {team1[3].name}")
    print(f"Team 2: {team2[0].name}, {team2[1].name}, {team2[2].name}, {team2[3].name} \n")
    
    global isAI
    
    global isTutorial
    isTutorial = False
    
    #for stopping battles that go on too long
    turnCounter = 0
    
    #list of all teammates and enemies
    combatants = []

    #adds characters from teammates and enemies list into combatants
    for chara in team1:
        combatants.append(chara)

    for chara in team2:
        combatants.append(chara)
    
    gameOver = False
    
    #this is the loop that defines the battle method
    while gameOver == False:
        for chara in combatants:
            chara.recoverTurnGauge()
            
            if chara.turnGauge >= 10000:
                isAI = False
                if chara in team1:
                    UseAbility.useAbility(chara, team2, team1, combatants)
                elif chara in team2:
                    UseAbility.useAbility(chara, team1, team2, combatants)
                turnCounter += 1

        #activating and continuing status conditions
        for chara in combatants:
            CheckStatus.checkStatus(chara)
        
        if team1[0].FOR <= 0 and team1[1].FOR <= 0 and team1[2].FOR <= 0 and team1[3].FOR <= 0:
            print(f"{team2[0].name}, {team2[1].name}, {team2[2].name} and {team2[3].name} have won")
            gameOver = True
        elif team2[0].FOR <= 0 and team2[1].FOR <= 0 and team2[2].FOR <= 0 and team2[3].FOR <= 0:
            print(f"{team1[0].name}, {team1[1].name}, {team1[2].name} and {team1[3].name} have won")
            gameOver = True
        elif turnCounter == 50:
            print("Time is up, the battle is a tie!")
            gameOver = True
        
        #if the battle is over, reset the characters for a new battle
        if gameOver == True:
            for chara in combatants:
                chara.resetCharacter()