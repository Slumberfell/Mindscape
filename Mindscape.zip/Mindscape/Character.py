'''
persistence = defense
passion = attack
compassion = amount healed and stats increased
initiative = speed
fortitude = hit points
'''

class Character:
    def __init__(self, name, PER, PAS, COM, INI, ability1, ability2, ability3, ability4):
        #core stats
        self.PER = PER
        self.PAS = PAS
        self.COM = COM
        self.INI = INI
        self.FOR = int(PAS/3 + COM/3 + INI/3)
        #default stats
        self.defaultPER = PER
        self.defaultPAS = PAS
        self.defaultCOM = COM
        self.defaultINI = INI
        self.defaultFOR = self.FOR
        self.defaultStatTotal = self.FOR + PAS + COM + INI
        #max stats
        self.maxFOR = self.defaultFOR * 1.5
        self.maxPAS = self.defaultPAS * 1.5
        self.maxCOM = self.defaultCOM * 1.5
        self.maxINI = self.defaultINI * 1.5
        #abilities (later to be of the Ability class)
        self.ability1 = ability1
        self.ability2 = ability2
        self.ability3 = ability3
        self.ability4 = ability4
        #a characters different focuses correlate to the max focus of the associated ability
        self.ability1Focus = self.ability1.maxFocus
        self.ability2Focus = self.ability2.maxFocus
        self.ability3Focus = self.ability3.maxFocus
        self.ability4Focus = self.ability4.maxFocus
        #other info
        self.name = name
        self.turnGauge = 0
        self.statusList = [] #holds all of a characters status effects that are applied to them
        self.statusCounterList = [] #index n here correlates to index n in StatusList
        
        #temporary stat change storage (for statuses like VUL, LIB, etc)
        tempPERup = 0
        tempPERdown = 0
        tempPASup = 0
        tempPASdown = 0
        tempCOMup = 0
        tempCOMdown = 0
        tempINIup = 0
        tempINIdown = 0
    
    def alterAllFocus(self, repNum):
        self.ability1Focus += repNum
        self.ability2Focus += repNum
        self.ability3Focus += repNum
        self.ability4Focus += repNum
        
        if self.ability1Focus > self.ability1.maxFocus:
            self.ability1Focus = self.ability1.maxFocus
            
        if self.ability2Focus > self.ability2.maxFocus:
            self.ability2Focus = self.ability2.maxFocus
            
        if self.ability3Focus > self.ability3.maxFocus:
            self.ability3Focus = self.ability3.maxFocus
            
        if self.ability4Focus > self.ability4.maxFocus:
            self.ability4Focus = self.ability4.maxFocus
            
    def depleteFocus(self, abilityX, depNum):
        if abilityX == self.ability1:
            self.ability1Focus -= depNum
        elif abilityX == self.ability2:
            self.ability2Focus -= depNum
        elif abilityX == self.ability3:
            self.ability3Focus -= depNum
        elif abilityX == self.ability4:
            self.ability4Focus -= depNum
        
    def addStatus(self, newStatus):
        self.statusList.append(newStatus) #adds a new status to the victim
        
    def recoverTurnGauge(self):
        self.turnGauge += int(self.INI)

    def resetCharacter(self): #allows the character to be properly used in the next battle
        self.FOR = self.defaultFOR
        self.PAS = self.defaultPAS
        self.COM = self.defaultCOM
        self.INI = self.defaultINI
        self.turnGauge = 0
        self.statusList.clear()
        self.statusCounterList.clear()
        self.ability1Focus = self.ability1.maxFocus
        self.ability2Focus = self.ability2.maxFocus
        self.ability3Focus = self.ability3.maxFocus
        self.ability4Focus = self.ability4.maxFocus