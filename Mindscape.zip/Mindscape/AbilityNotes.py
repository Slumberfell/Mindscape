'''
 - Defense effects
PERu = persistence up semi-permanently
DEF = increase PER for a short time
PASd = passion down
PAC = pacification (prevents victims from using damaging moves)
END = enduring (cannot go below 1 FOR)
BG = body guarding (if any ally is to receive damage, the body guard receives a part of it)
VE = veil (prevents the target from being character read)

 - Offense effects
PASu = passion up semi-permanently
PERd = persistence down semi-permanently
VUL = vulnerable (raised PAS for a short time)
COMd = compassion down semi-permanently
DOT = damage over time, lasts for 3 turns
statusDMG = more damage the higher the number of statuses on the target
IGN = damage ignores END, DEF and part of PER
High power = 75 or above (not in effect list)

 - Support effects
COMu = compassion up semi-permanently
HOT = healing over time
H = power-independent healing (for if a move has positive power but should still heal)
CLE = cleanse (removes all statuses)
REV = revival (massively heals the target, but only when they are defeated)
Fu = increases the focus of all the target's moves by 1
Negative power = healing
LS = life steal

 - Manager effects
INId = initiative down
INIu = initiative up
OPP = oppression (initiative is temporarily reduced)
LIB = liberation (initiative is temporarily raised)
PRV = provocation (forces targets to use only damaging moves)
CR = character read (displays specific character info)
TGu = turn gauge up (by a standard 2000 points)
TGd = turn gauge down (by a standard 2000 points)
Fd = decreases the focus of all the target's moves by 1

 - Role-neutral effects
AOE = area of effect. Makes other effects affect more characters
SAC = sacrifice (the user damages themself proportional to their own PAS)
RC = recoil (user is inflicted with damage proportional to the damage inflicted)
'''

'''
MAKE EACH MOVE BE ON THE SAME "TIER"
------------------------------------
-FOCUS-
3 focus: +1
5 focus: +2
7 focus: +3

-POWER-
0 power:     +0
25 power:    +1
50 power:    +2
75 power:    +3
100 power:   +4

-ADDITIONL EFFECTS-
harmful:     -1
none:        +-0
lesser :     +1
mid:         +2
greater:     +3

-TARGETTING-
AOE + team:        *4
AOE + ally:        *3.5
not AOE + any:     *2
not AOE + not any: *1

This is a general outline, not a concrete set of rules
'''

'''
TARGETSETTNG INFO
-----------------
enemy        = a single enemy
enemy + AOE  = entire enemy team
team         = one of your teammates (includes yourself)
team + AOE   = all of your team (includes yourself)
ally         = one ally (excludes yourself)
ally + AOE   = all allies (excludes yourself)
any          = any single character could be the target
any + AOE    = any one team
self         = only yourself

IMPORTANT NOTE: targetSetting is for the target of damage and healing,
while also giving a default target to an additional effect.
Attachments like "self" and "team" in an ability status list are for directing where additional 
effects should go, rather than damage or healing.
'''