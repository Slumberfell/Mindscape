import Battles
from CharacterCreation import *
import time
import Display
'''
TODO
- fix crashing when choosing an out of bounds option
- reimplement/reactivate the AI
- print character health text to be of different colors
- add fifth option to give info about moves, remove the displayTip method alongside this
- make damaging moves also have the capacity to give a positive status to team (replace "AOE" with "team", "allies" and "enemies" tags)
- add a timer when choosing a move
- give players the ability to choose their ability pool for their avatar
- give characters passive abilities
- implement environments
- implement weather
- move BG and END out of damage calc and into ApplyNonstatusEffect
- make mult-target moves less of a mess when printed on-screen
- make summoning moves (only reasonably doable if UseAbility takes in lists instead)
- complicate the AI
- add basic visuals
'''
if __name__ == '__main__':
    timeWait = 0.5
    
    #test battle
    #Battles.tutorialBattle(sackOfBeans1, sackOfBeans2, servantOfTheOverseer, overseer)
   
    print("This is a text based video game, where you will need to give an input and then press enter")
    print("The lower the text, the more recent it is")  
    confirmContinue = input("PRESS ENTER TO CONTINUE")

doLoop = True
while doLoop == True:
    #avatar customization
    print("Choose a name for your character, then press ENTER")
    chosenName = input()
    chosenRole = 5
    
    validChoice = False
    while validChoice == False:
        try:
            print("\nChoose your role (select a number from 1 to 5 and press ENTER)...")
            print("1.Defense    2.Offense     3.Support     4.Manager    5.More information")
            chosenRole = int(input())
        
            if(chosenRole == 1):
                print("Defense role chosen")
                avatar = Character(chosenName, 1300, 900, 900, 900, headbutt, discombobulate, shove, wondrousBarrier)
                ally1 = blondie
                ally2 = sevenfold
                ally3 = lynyrd
                validChoice = True
            elif(chosenRole == 2):
                print("Offense role chosen")
                avatar = Character(chosenName, 900, 1300, 900, 900, backHandSlap, rawMuscle, sulfuricAcid, hypeUp)
                ally1 = metric
                ally2 = sevenfold
                ally3 = lynyrd
                validChoice = True
            elif(chosenRole == 3):
                print("Support role chosen")
                avatar = Character(chosenName, 900, 900, 1300, 900, bite, bigOlSmooch, pray, rinse)
                ally1 = metric
                ally2 = blondie
                ally3 = lynyrd
                validChoice = True
            elif(chosenRole == 4):
                print("Manager role chosen")
                avatar = Character(chosenName, 900, 900, 900, 1300, dare, flow, soulRead, slobber)
                ally1 = metric
                ally2 = blondie
                ally3 = sevenfold
                validChoice = True
            else:
                print("Defenders prevent damage to your team; these are based around persistence (PER)")
                print("Offenders eliminate opponents efficiently; these are based around passion (PAS)")
                print("Supporters recover your team after injuries; these are based around compassion (COM)")
                print("Managers oversee how and when turns are used; these are based around initiative (INI)")
        except ValueError:
            print("Invalid input, please enter a valid number.")
        time.sleep(timeWait)
    
        Display.displayInfo(avatar)
        confirmContinue = input("\nPRESS ENTER TO CONTINUE")
        
        exitBattleChoice = False
        while exitBattleChoice == False:
            print("Would you like to enter a full battle, enter into the tutorial or remake your avatar? (type 1, 2 or 3, then ENTER)")
            time.sleep(timeWait)
            print("1. Full Battle    2. Tutorial    3. Remake my avatar")
            chooseBattle = int(input())
            time.sleep(timeWait)
            
            if chooseBattle == 1:
                team1 = [avatar, ally1, ally2, ally3]
                #allies = [ally1, ally2, ally3]
                team2 = [dragonHeart, coolChameleon, leafyParrot, aergia]
            elif chooseBattle == 2:
                team1 = [avatar, sentientCodex]
                #lies = [sentientCodex]
                team2 = [servantOfTheOverseer, overseer]
                
            elif chooseBattle == 3:
                exitBattleChoice = True
            else:
                print("Invalid input, please enter a valid number.")
                continue
            Battles.battle(team1, team2)