import time
import random
timeWait = 0.2

def displayInfo(chara):
    print("-----------------------------")
    print(f"{chara.name}'s information")
    print(f" - Persistence   {chara.PER}")
    print(f" - Passion       {chara.PAS}")
    print(f" - Compassion    {chara.COM}")
    print(f" - Initiative    {chara.INI}")
    print(f" - Fortitude     {chara.FOR}")
    print(" - Moves")
    print(f"   > {chara.ability1.name}")
    print(f"   > {chara.ability2.name}")
    print(f"   > {chara.ability3.name}")
    print(f"   > {chara.ability4.name}")
    print("-----------------------------")
    time.sleep(timeWait*2)

def displayGeneralFortitude(chara):
    if chara.FOR <= 0:
        print(f"{chara.name} is asleep")
    elif chara.FOR <= chara.defaultFOR * (1/3):
        print(f"{chara.name} is on the brink of collapse!")
    elif chara.FOR <= chara.defaultFOR * (2/3):
        print(f"{chara.name} is somewhat unhealthy")
    elif chara.FOR <= chara.defaultFOR:
        print(f"{chara.name} is quite healthy")
    elif chara.FOR > chara.defaultFOR:
        print(f"{chara.name} is healthier than usual")
    time.sleep(timeWait)

def displayTurnGauge(chara):
    print(f"{chara.name}'s turn gauge: {chara.turnGauge} \n")
    time.sleep(timeWait)

#def explainAbilities(abilityX):
    
'''
def displayTip(abilityX):
    print("\n----------------")
    print("TIP!")
    print("Your goal is to make the other team too unhealthy to fight. Not all characters go about this in the same way\n")
    if abilityX == None:
        print("In the Mindscape, the line between sleep and death does not exist.")
        print("A sleeping character can be revived through enough healing.")
    else:
        #Defense effects
        if "PASd" in abilityX.getAllAddiEffects():
            print("Lower passion means that character does less damage.")
            
        if "PAC" in abilityX.getAllAddiEffects():
            print("Pacified characters are too stunned or frightened to attack.")
        
        if "INV" in abilityX.getAllAddiEffects():
            print("Any damage inflicted to invincible targets is zero.")
            
        if "BG" in abilityX.getAllAddiEffects():
            print("Bodying guarding characters reduce damage to their allies by diverting some of the damage to themselves.")
        
        if "DEF" in abilityX.getAllAddiEffects():
            print("The defending status halves any damage you take.")
        
        if "END" in abilityX.getAllAddiEffects():
            print("The enduring status prevents you from dying, but does not prevent damage nor heal wounds.")
        
        if "VE" in abilityX.getAllAddiEffects():
            print("Veiled characters cannot have their specific information displayed")
        
        #Offense effects
        if "PASu" in abilityX.getAllAddiEffects():
            print("More passion means that character does more damage.")
            
        if "COMd" in abilityX.getAllAddiEffects():
            print("Less compassion means that character will heal for less.")

        if "VUL" in abilityX.getAllAddiEffects():
            print("The vulnerable status doubles any damage you take until your next turn.")
        
        if "DOT" in abilityX.getAllAddiEffects():
            print("Damage over time is a status effect that automatically inflicts damage every so often.")
            
        if "statusDMG" in abilityX.getAllAddiEffects():
            print("This ability inflicts more damage based on the target's number of statuses.")
        
        if "IGN" in abilityX.getAllAddiEffects():
            print("This ability ignores statuses that prevent damage.")
            
        if abilityX.power >= 75:
            print("Each ability has 'power', which determines how much damage they do.")
    
        #Support effects
        if "COMu" in abilityX.getAllAddiEffects():
            print("More compassion means that character heals more.")
            
        if "HOT" in abilityX.getAllAddiEffects():
            print("Healing over time operates automatically, independent of the character who used it.")
            
        if "LS" in abilityX.getAllAddiEffects():
            print("Life stealing abilities recover the user's fortitude by half the damage inflicted.")
        
        if abilityX.power < 0:
            print("Healing abilities allow your team to survive for longer.")
            
        if "CLE" in abilityX.getAllAddiEffects():
            print("Cleansing indiscriminately removes all statuses on the target.")
            
        if "REV" in abilityX.getAllAddiEffects():
            print("Reviving heals targets, but only if they are defeated.")
            
        if "Fu" in abilityX.getAllAddiEffects():
            print("You need a resource called focus to use any ability.")
            print("This ability gives you more of this.")
        
        #Manager effects
        if "INIu" in abilityX.getAllAddiEffects():
            print("This ability increases initiative, making a character swifter.")
            print("The more initiative, the sooner each of that character's turns come")
            
        if "CR" in abilityX.getAllAddiEffects():
            print("The specifics of a character are usually hidden or obscured.")
            print("Some abilities help this by displaying such information.")
            
        if "INId" in abilityX.getAllAddiEffects():
            print("This ability decreases initiative.")
            print("Less initiative means a character's turns will come later.")
            
        if "PRV" in abilityX.getAllAddiEffects():
            print("Provoked targets are forced to use damaging abilities.")
            
        if "TGu" in abilityX.getAllAddiEffects():
            print("This ability increases a character's turn gauge. The higher a turn gauge, the sooner the next turn comes.")
            
        if "TGd" in abilityX.getAllAddiEffects():
            print("This ability decreases a character's turn gauge. The lower a turn gauge, the later the next turn comes.")
    
        if "Fd" in abilityX.getAllAddiEffects():
            print("You need a resource called focus to use any ability.")
            print("This ability takes away focus from a character.")
    print("\nA character gets a turn if their turn gauge is 10000 or more.")
    print("----------------\n")
    time.sleep(timeWait*4)
'''