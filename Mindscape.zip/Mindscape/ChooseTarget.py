import Battles
import random

def chooseTarget(abilityX, user, enemies, teammates, combatants):        
    #setting up allies list
    allies = []
    for chara in teammates:
        if chara != user:
            allies.append(chara)

    #chosenTarget represents an index in a list of characters. Target is the list of or individual characters
    chosenTarget = 1 #a number that correlates to the actual character object. This is the default
    validTarget = False
    while validTarget == False:
        
        #establish the target
        if abilityX.targetSetting == "enemy":
            target = enemies
        elif abilityX.targetSetting == "team":
            target = teammates
        elif abilityX.targetSetting == "ally":
            target = allies
        elif abilityX.targetSetting == "self":
            target = user
        elif abilityX.targetSetting == "any":
            target = combatants

        #if the target is a specific character in a list, which one?
        if "AOE" not in abilityX.getAllAddiEffects() and target != user:
            #chooses randomly if AI is in control
            if Battles.isAI == True:
                #chosen target is meant to point to a specific character in the target list
                chosenTarget = random.randint(1,len(target))
            else:
                print(f"Whom is the target of {user.name}'s {abilityX.name}?")
                
                #prints adaptable text consistent with previous texts
                choiceNum = 1 #choiceNum is just for text
                for chara in target:
                    print(f"{choiceNum}. {chara.name}")
                    choiceNum += 1
                
                #asks player for their choice, and prepares for an invalid input
                try:
                    #chosen target is meant to point to a specific character in the target list
                    chosenTarget = int(input())
                except ValueError:
                    print("Invalid input, try again\n")
                    validTarget = False
                    continue    
                #after everything, we set target to be a list of a single character
                finalTarget = [target[chosenTarget-1]] #this is a list because later operations assume that target is a list
                validTarget = True
        else:
            validTarget = True
            finalTarget = target
    return finalTarget