from Ability import Ability

beASackOfBeans = Ability("Be a Sack of Beans", 0, 3, "self")

#Defense moves -----------------------------------------
galvanize = Ability("Galvanize", 0, 7, "team")
galvanize.giveEffect("DEF")
galvanize.giveEffect(" ")

headbutt = Ability("Headbutt", 500, 7, "enemy")
headbutt.giveEffect("RC")
headbutt.giveEffect("PASd")
headbutt.giveEffect("self")

wondrousBarrier = Ability("Wondrous Barrier", 0, 3, "team")
wondrousBarrier.giveEffect("DEF")
wondrousBarrier.giveEffect("AOE")

brace = Ability("Brace", 0, 5, "self")
brace.giveEffect("END")
brace.giveEffect("DEF")
brace.giveEffect(" ")

dragonRing = Ability("Dragon Ring", 0, 3, "team")
dragonRing.giveEffect("AOE")

discombobulate = Ability("Discombobulate", 250, 3, "enemy")
discombobulate.giveEffect("PAC")
discombobulate.giveEffect(" ")

nightmarishIllusion = Ability("Frightening Illusion", 0, 3, "enemy")
nightmarishIllusion.giveEffect("PAC")
nightmarishIllusion.giveEffect("AOE")

dreamyIllusion = Ability("Dreamy Illusion", 0, 3, "enemy")
dreamyIllusion.giveEffect("PASd")
dreamyIllusion.giveEffect("AOE")

shroudOfScreams = Ability("Shroud of Screams", 0, 3, "team")
shroudOfScreams.giveEffect("VE")
shroudOfScreams.giveEffect("AOE")
shroudOfScreams.giveEffect("END")
shroudOfScreams.giveEffect("AOE")

ironCurtain = Ability("Iron Curtain", 0, 5, "self")
ironCurtain.giveEffect("VE")
ironCurtain.giveEffect("DEF")
ironCurtain.giveEffect(" ")

#Offense moves -----------------------------------------
claw = Ability("Claw", 250, 7, "enemy")
claw.giveEffect("DOT")
claw.giveEffect(" ")

scorchingCone = Ability("Scorching Cone", 500, 5, "enemy")
scorchingCone.giveEffect("TGd")
scorchingCone.giveEffect("self")
scorchingCone.giveEffect("DOT")
scorchingCone.giveEffect("AOE")

lavaRush = Ability("Lava Rush", 500, 5, "enemy")
lavaRush.giveEffect("TGd")
lavaRush.giveEffect("AOE")

turnToAsh = Ability("Turn to Ash", 1000, 3, "enemy")
turnToAsh.giveEffect("DOT")
turnToAsh.giveEffect("SAC")
turnToAsh.giveEffect("DOT")
turnToAsh.giveEffect("self")

frenziedFlailing = Ability("Frenzied Flailing", 500, 5, "enemy")
frenziedFlailing.giveEffect("SAC")
frenziedFlailing.giveEffect("AOE")

bite = Ability("Bite", 500, 5, "enemy")
bite.giveEffect("DOT")
bite.giveEffect(" ")

backHandSlap = Ability("Back-Hand Slap", 500, 5, "enemy")
backHandSlap.giveEffect("COMd")
backHandSlap.giveEffect(" ")

tongueStab = Ability("Tongue Stab", 500, 5, "enemy")
tongueStab.giveEffect("DOT")
tongueStab.giveEffect(" ")

flameCircle = Ability("Flame Circle", 250, 3, "enemy")
flameCircle.giveEffect("DOT")
flameCircle.giveEffect("AOE")

sulfuricAcid = Ability("Sulfuric Acid!", 250, 3, "enemy")
sulfuricAcid.giveEffect("VUL")
sulfuricAcid.giveEffect(" ")

bedazzle = Ability("Bedazzle", 0, 3, "enemy")
bedazzle.giveEffect("VUL")
bedazzle.giveEffect("AOE")

hypeUp = Ability("Hype Up", 0, 3, "team")
hypeUp.giveEffect("PASu")
hypeUp.giveEffect("AOE")

rawMuscle = Ability("Raw Muscle", 500, 5, "enemy")
rawMuscle.giveEffect("IGN")
rawMuscle.giveEffect(" ")

omenOfDeath = Ability("Omen of Death", 0, 3, "enemy")
omenOfDeath.giveEffect("VUL")
omenOfDeath.giveEffect("PASu")
omenOfDeath.giveEffect("self")

breakDown = Ability("BREAK DOWN", 500, 5, "enemy")
breakDown.giveEffect("VUL")
breakDown.giveEffect(" ")

vulgarImage = Ability("Vulgar Image", 250, 5, "enemy")
vulgarImage.giveEffect("VUL")
vulgarImage.giveEffect("DOT")
vulgarImage.giveEffect(" ")

hotTake = Ability("Hot Take", 0, 3, "enemy")
hotTake.giveEffect("PRV")
hotTake.giveEffect("AOE")
hotTake.giveEffect("COMd")
hotTake.giveEffect("AOE")

piercingHeavens = Ability("Piercing Heavens", 750, 3, "enemy")
piercingHeavens.giveEffect("IGN")
piercingHeavens.giveEffect(" ")

judgeUnworthy = Ability("Judge Unworthy", 250, 5, "enemy")
judgeUnworthy.giveEffect("statusDMG")
judgeUnworthy.giveEffect(" ")

decapitate = Ability("Decapitate", 750, 5, "enemy")
decapitate.giveEffect("DOT")
decapitate.giveEffect("COMd")
decapitate.giveEffect("self")

peck = Ability("Peck", 250, 7, "enemy")
peck.giveEffect("LS")
peck.giveEffect(" ")

#Support moves -----------------------------------------
drain = Ability("Drain", 250, 7, "enemy")
drain.giveEffect("H")
drain.giveEffect(" ")

bigOlSmooch = Ability("Big Ol' Smooch", -500, 7, "ally")
bigOlSmooch.giveEffect(" ")

cropMilk = Ability("Crop Milk", 0, 5, "ally")
cropMilk.giveEffect("HOT")
cropMilk.giveEffect("COMu")
cropMilk.giveEffect("self")

pray = Ability("Pray", 0, 3, "team")
pray.giveEffect("HOT")
pray.giveEffect("AOE")
pray.giveEffect("CLE")
pray.giveEffect("AOE")

gift = Ability("Gift", 0, 5, "ally")
gift.giveEffect("COMu")
gift.giveEffect("AOE")

rinse = Ability("Rinse", 0, 5, "team")
rinse.giveEffect("CLE")
rinse.giveEffect("AOE")

clingToHope = Ability("Cling to Hope", -500, 3, "team")
clingToHope.giveEffect("REV")
clingToHope.giveEffect("AOE")
clingToHope.giveEffect("END")
clingToHope.giveEffect("AOE")

#Manager moves -----------------------------------------
jolt = Ability("Jolt", 250, 5, "enemy")
jolt.giveEffect("TGd")
jolt.giveEffect(" ")

duneBlast = Ability("Dune Blast", 250, 3, "enemy")
duneBlast.giveEffect("TGd")
duneBlast.giveEffect("AOE")

stare = Ability("Stare", 0, 5, "enemy")
stare.giveEffect("PAC")
stare.giveEffect("CR")
stare.giveEffect(" ")

soulRead = Ability("Soul Read", 0, 7, "any")
soulRead.giveEffect("CR")
soulRead.giveEffect("TGu")
soulRead.giveEffect("self")

analyze = Ability("Analyze", 0, 5, "any")
analyze.giveEffect("CR")
analyze.giveEffect("Fu")
analyze.giveEffect("self")

slobber = Ability("Slobber", 250, 5, "enemy")
slobber.giveEffect("INId")
slobber.giveEffect(" ")

tentacleSnare = Ability("Tentacle Snare", 250, 3, "enemy")
tentacleSnare.giveEffect("INId")
tentacleSnare.giveEffect("AOE")

flow = Ability("Flow", 0, 5, "team")
flow.giveEffect("INIu")
flow.giveEffect("TGu")
flow.giveEffect(" ")

windsOfChange = Ability("Winds of Change", 0, 3, "team")
windsOfChange.giveEffect("INIu")
windsOfChange.giveEffect("AOE")

dare = Ability("Dare", 0, 5, "enemy")
dare.giveEffect("PRV")
dare.giveEffect(" ")

boast = Ability("Boast", 0, 3, "enemy")
boast.giveEffect("PRV")
boast.giveEffect("AOE")

scuttle = Ability("Scuttle", 0, 3, "self")
scuttle.giveEffect("INIu")
scuttle.giveEffect("TGu")
scuttle.giveEffect(" ")

shove = Ability("Shove", 500, 5, "enemy")
shove.giveEffect("TGd")
shove.giveEffect(" ")

#Defense + offense -----------------------------------------
recklessHammering = Ability("Reckless Hammering", 750, 3, "enemy")
recklessHammering.giveEffect("PAC")
recklessHammering.giveEffect("RC")
recklessHammering.giveEffect(" ")

determinationFactor100 = Ability("DETERMINATION FACTOR 100", 0, 5, "self")
determinationFactor100.giveEffect("PASd")
determinationFactor100.giveEffect("END")
determinationFactor100.giveEffect(" ")

jumpScare = Ability("Jump Scare", 0, 3, "enemy")
jumpScare.giveEffect("PAC")
jumpScare.giveEffect("VUL")
jumpScare.giveEffect(" ")

#Defense + support -----------------------------------------
promise = Ability("Promise", -1000, 3, "ally")
promise.giveEffect("REV")
promise.giveEffect("BG")
promise.giveEffect("self")

#Defense + manager -----------------------------------------
pacify = Ability("Pacify", 0, 3, "enemy")
pacify.giveEffect("HOT")
pacify.giveEffect("PRV")
pacify.giveEffect("PAC")
pacify.giveEffect(" ")

sigilOfShadows = Ability("Sigil of Shadows", 0, 3, "team")
sigilOfShadows.giveEffect("SAC")
sigilOfShadows.giveEffect("INIu")
sigilOfShadows.giveEffect("VE")
sigilOfShadows.giveEffect(" ")

shadowStep = Ability("Shadowstep", 0, 5, "self")
shadowStep.giveEffect("INIu")
shadowStep.giveEffect(" ")

#Offense + support -----------------------------------------
visualize = Ability("Visualize", 0, 3, "self")
visualize.giveEffect("Fu")
visualize.giveEffect("INIu")
visualize.giveEffect(" ")

#Offense + manager
jilt = Ability("Jilt", 1000, 3, "enemy")
jilt.giveEffect("SAC")
jilt.giveEffect("TGd")
jilt.giveEffect(" ")

prickOfCorruption = Ability("Prick Of Corruption", 250, 3, "enemy")
prickOfCorruption.giveEffect("DOT")
prickOfCorruption.giveEffect("Fd")
prickOfCorruption.giveEffect(" ")

launch = Ability("Launch", 0, 5, "self")
launch.giveEffect("TGu")
launch.giveEffect("PASu")
launch.giveEffect(" ")

biteOfFruit = Ability("Bite of Fruit", 0, 5, "any")
biteOfFruit.giveEffect("CR")
biteOfFruit.giveEffect("SAC")
biteOfFruit.giveEffect("PASu")
biteOfFruit.giveEffect("self")

spiderSwarm = Ability("Spider Swarm", 0, 5, "enemy")
spiderSwarm.giveEffect("DOT")
spiderSwarm.giveEffect("Fd")
spiderSwarm.giveEffect(" ")

spiderDance = Ability("Spider Dance", 0, 3, "team")
spiderDance.giveEffect("INIu")
spiderDance.giveEffect("self")
spiderDance.giveEffect("PASu")
spiderDance.giveEffect("AOE")

witnessTheEnd = Ability("Witness the End", 0, 5, "enemy")
witnessTheEnd.giveEffect("CR")
witnessTheEnd.giveEffect("VUL")
witnessTheEnd.giveEffect(" ")

#Support + manager
sap = Ability("Sap", 0, 3, "enemy")
sap.giveEffect("Fu")
sap.giveEffect("self")
sap.giveEffect("Fd")
sap.giveEffect(" ")

derangedRant = Ability("Deranged Rant", 0, 3, "self")
derangedRant.giveEffect("Fu")
derangedRant.giveEffect("PRV")