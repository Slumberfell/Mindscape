from Character import Character
from AbilityCreation import *
import time

'''
RULES FOR DEVELOPERS
- default of 4000 points to allocate into a characters four main stats: PER, PAS, COM, INI
- if all four main stats are equal, add 5 to each of them
- by default, 250 points are added into a stat that character specializes in. That stat is based on their role
'''
#test characters
sackOfBeans1 = Character("a dumb sack of beans", 1000, 1000, 1000, 1000, galvanize, sulfuricAcid, beASackOfBeans, beASackOfBeans)
sackOfBeans2 = Character("a dirty sack of beans", 1000, 1000, 1000, 1000, galvanize, sulfuricAcid, beASackOfBeans, beASackOfBeans)

#pure defense
metric = Character("Metric", 1300, 930, 920, 850, shove, discombobulate, bite, boast)

overseer = Character("Overseer", 1500, 900, 750, 850, stare, judgeUnworthy, boast, shove)

#pure offense
blondie = Character("Blondie", 900, 1300, 880, 920, backHandSlap, tongueStab, rawMuscle, flameCircle)

#pure support
sevenfold = Character("Sevenfold", 910, 910, 1300, 880, bite, pray, rinse, wondrousBarrier)

servantOfTheOverseer = Character("Servant of the Overseer", 900, 900, 1250, 950, pray, gift, jilt, shove)

#pure manager
lynyrd = Character("Lynyrd", 900, 900, 900, 1300, flow, dare, slobber, analyze)

#defense + offense
dragonHeart = Character("Dragon Heart", 1250, 1250, 750, 750, recklessHammering, headbutt, dragonRing, flameCircle)

#support + offense
coolChameleon = Character("Cool Chameleon", 740, 1250, 1250, 760, pray, gift, bedazzle, tongueStab)

#manager + support
leafyParrot = Character("Leafy Parrot", 750, 750, 1240, 1260, peck, cropMilk, analyze, windsOfChange)

sentientCodex = Character("Sentient Codex", 900, 900, 1100, 1100, soulRead, flow, vulgarImage, promise)

#defense + manager
aergia = Character("Aergia", 1250, 750, 750, 1250, nightmarishIllusion, dreamyIllusion, flow, tentacleSnare)